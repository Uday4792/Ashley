import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
 
public class JSON_To_XML_Map {
 
    public static final String xmlFilePath = "Xmlfile_ASH.xml";
 
    public static void main(String argv[]) throws IOException, ParseException {
        try {
        	
        	Object obj = new JSONParser().parse(new FileReader("PO.json")); 
            JSONObject jo = (JSONObject) obj; 
            String streetAddress = "",city = "",state = "",sku = "",description = "",zip = "";
            Integer LINE_COUNT=0;
            double rate = 0;
            long quantity = 0;
              
            // getting address 
            Map address = ((Map)jo.get("delivery_address")); 
            Iterator<Map.Entry> itr1 = address.entrySet().iterator(); 
            while (itr1.hasNext()) { 
                Map.Entry pair = itr1.next(); 
                //System.out.println(pair.getKey() + " : " + pair.getValue()); 
                if(pair.getKey().equals("address"))
                {
                	streetAddress = (String) pair.getValue();
                }
                if(pair.getKey().equals("city"))
                {
                	city = (String) pair.getValue();
                }
                if(pair.getKey().equals("state"))
                {
                	state = (String) pair.getValue();
                }
                if(pair.getKey().equals("zip"))
                {
                	zip = (String) pair.getValue();
                }
            } 
            
            Map billing_address = ((Map)jo.get("billing_address")); 
            Iterator<Map.Entry> itr3 = billing_address.entrySet().iterator(); 
            while (itr3.hasNext()) { 
                Map.Entry pair1 = itr3.next(); 
                //System.out.println(pair1.getKey() + " : " + pair1.getValue()); 
            } 

            
            String date = (String) jo.get("date");
            String discount_amount_formatted = (String) jo.get("discount_amount_formatted");
            //System.out.println("Point-2");
            long tax_total = (long) jo.get("tax_total");
            
            String delivery_org_address_id = (String) jo.get("delivery_org_address_id");
            String adjustment_formatted = (String) jo.get("adjustment_formatted");
            
            boolean is_discount_before_tax = (boolean) jo.get("is_discount_before_tax");
            
            long discount_amount = (long) jo.get("discount_amount");
            String purchaseorder_id = (String) jo.get("purchaseorder_id");
            String expected_delivery_date = (String) jo.get("expected_delivery_date");
            String discount_account_id = (String) jo.get("discount_account_id");
            long discount = (long) jo.get("discount");
            
            String currency_code = (String) jo.get("currency_code");
            double total = (double) jo.get("total");
            String expected_delivery_date_formatted = (String) jo.get("expected_delivery_date_formatted");
            String tax_total_formatted = (String) jo.get("tax_total_formatted");
            String date_formatted = (String) jo.get("date_formatted");
            String sub_total_formatted = (String) jo.get("sub_total_formatted");
            //System.out.println("Point-3");
            //String custom_field_hash = (String) jo.get("custom_field_hash");
            String adjustment_description = (String) jo.get("adjustment_description");
            String delivery_customer_id = (String) jo.get("delivery_customer_id");
            long exchange_rate = (long) jo.get("exchange_rate");
            String currency_symbol = (String) jo.get("currency_symbol");
            //String custom_fields = (String) jo.get("custom_fields");
            //System.out.println("Point-4");
            String ship_via_id = (String) jo.get("ship_via_id");
            String vendor_name = (String) jo.get("vendor_name");
            String status_formatted = (String) jo.get("status_formatted");
            String reference_number = (String) jo.get("reference_number");
            String purchaseorder_number = (String) jo.get("purchaseorder_number");
            String delivery_date = (String) jo.get("delivery_date");
            String delivery_date_formatted = (String) jo.get("delivery_date_formatted");
            String vendor_id = (String) jo.get("vendor_id");
            double sub_total = (double) jo.get("sub_total");
            String ship_via = (String) jo.get("ship_via");
            String attention = (String) jo.get("attention");
            long adjustment = (long) jo.get("adjustment");
            String total_formatted = (String) jo.get("total_formatted");
            String currency_id = (String) jo.get("currency_id");
            String status = (String) jo.get("status");


            JSONArray ja = (JSONArray) jo.get("line_items"); 
            Iterator itr2 = ja.iterator(); 
 
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
 
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
 
            Document document = documentBuilder.newDocument();
            
           // root element
            Element root = document.createElement("furnPO:order");
            root.setAttributeNS(XMLConstants.XMLNS_ATTRIBUTE_NS_URI, "xmlns:" + "furnPO", "http://support.furnishnet.com/xml/schemas/FurnPO_v1.8");
            root.setAttributeNS(XMLConstants.XMLNS_ATTRIBUTE_NS_URI, "xmlns:" + "fnBase", "http://support.furnishnet.com/xml/schemas/fnBase_v1.4");
            root.setAttributeNS(XMLConstants.XMLNS_ATTRIBUTE_NS_URI, "xmlns:" + "fnItem", "http://support.furnishnet.com/xml/schemas/fnItem_v1.4");
            root.setAttributeNS(XMLConstants.XMLNS_ATTRIBUTE_NS_URI, "xmlns:" + "fnParty", "http://support.furnishnet.com/xml/schemas/fnParty_v1.4");
            root.setAttributeNS(XMLConstants.XMLNS_ATTRIBUTE_NS_URI, "xmlns:" + "xsi", "http://www.w3.org/2001/XMLSchema-instance");
            root.setAttributeNS(XMLConstants.XML_NS_URI, "xsi:" + "schemaLocation", "http://support.furnishnet.com/xml/schemas/FurnPO_v1.8 http://support.furnishnet.com/xml/schemas/FurnXMLPO_v1.8.xsd");
            document.appendChild(root);
 
            // employee element
            Element Order = document.createElement("Order");
 
            root.appendChild(Order);
 
            // set an attribute to staff element
            Attr attr = document.createAttribute("comment");
            attr.setValue("ORDERLEVELCUSTOMERCOMMENT");
            Order.setAttributeNode(attr);
            
            Element document1 = document.createElement("document");
            Order.appendChild(document1);
            
            Attr attr1 = document.createAttribute("id");
            attr1.setValue("27958");
            document1.setAttributeNode(attr1);
            
            Attr attr2 = document.createAttribute("status");
            attr2.setValue("Original");
            document1.setAttributeNode(attr2);
            
            Attr attr3 = document.createAttribute("type");
            attr3.setValue("850");
            document1.setAttributeNode(attr3);
            
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
            LocalDateTime now = LocalDateTime.now();  
            System.out.println(dtf.format(now));  
            
            Element firstName1 = document.createElement("creationDate");
            firstName1.appendChild(document.createTextNode(dtf.format(now)));
            document1.appendChild(firstName1);
 
            //you can also use staff.setAttribute("id", "1") for this
 
            // firstname element
            Element firstName = document.createElement("currency");
            firstName.appendChild(document.createTextNode("USD"));
            Order.appendChild(firstName);
 
            Element buyer = document.createElement("buyer");
            Order.appendChild(buyer);
            
            Element buyer_partyIdentifier = document.createElement("fnParty:partyIdentifier");
            buyer.appendChild(buyer_partyIdentifier);
            
            Attr attr4 = document.createAttribute("partyIdentifierCode");
            attr4.setValue("3846300");
            buyer_partyIdentifier.setAttributeNode(attr4);
            
            Attr attr5 = document.createAttribute("partyIdentifierQualifierCode");
            attr5.setValue("SenderAssigned");
            buyer_partyIdentifier.setAttributeNode(attr5);
            
            Element seller = document.createElement("seller");
            Order.appendChild(seller);
            
            Element sellerIdentification = document.createElement("sellerIdentification");
            seller.appendChild(sellerIdentification);
            
            Element seller_partyIdentifier = document.createElement("fnParty:partyIdentifier");
            sellerIdentification.appendChild(seller_partyIdentifier);
            
            Attr attr6 = document.createAttribute("partyIdentifierCode");
            attr6.setValue("052738531");
            seller_partyIdentifier.setAttributeNode(attr6);
            
            Attr attr7 = document.createAttribute("partyIdentifierQualifierCode");
            attr7.setValue("DUNS");
            seller_partyIdentifier.setAttributeNode(attr7);
            
            Element shipTo = document.createElement("shipTo");
            Order.appendChild(shipTo);
            
            Attr attr8 = document.createAttribute("id");
            switch(zip) 
            {
	            case "08861" :  attr8.setValue("01"); break;
	            case "11727" :  attr8.setValue("02"); break;
	            case "11772" :  attr8.setValue("04"); break;
	            case "07652" :  attr8.setValue("05"); break;
	            case "12550" :  attr8.setValue("06"); break;
	            case "11735" :  attr8.setValue("07"); break;
	            default : attr8.setValue("01");
	         }
            
            shipTo.setAttributeNode(attr8);
            
            Element shipTo_partyIdentifier = document.createElement("fnParty:partyIdentifier");
            shipTo.appendChild(shipTo_partyIdentifier);
            
            Attr attr9 = document.createAttribute("partyIdentifierCode");
            attr9.setValue("01");
            shipTo_partyIdentifier.setAttributeNode(attr9);
            
            Attr attr10 = document.createAttribute("partyIdentifierQualifierCode");
            attr10.setValue("ReceiverAssigned");
            shipTo_partyIdentifier.setAttributeNode(attr10);
            
            Element shipComplete = document.createElement("shipComplete");
            shipComplete.appendChild(document.createTextNode("ShipItemsAsAvailable or ShipOnlyCompleteOrder"));
            Order.appendChild(shipComplete);
            
            
            Integer i = 0;
            //Line Level Creation Starts
            while (itr2.hasNext())  
            { 
                itr1 = ((Map) itr2.next()).entrySet().iterator(); 
                LINE_COUNT = LINE_COUNT + 1;
                
                while (itr1.hasNext()) 
                { 
                    Map.Entry pair = itr1.next(); 
                    //System.out.println(pair.getKey() + " : " + pair.getValue()); 
                    if(pair.getKey().equals("quantity")) 
                    {
                    	quantity = (long) pair.getValue();
                    }
                    if(pair.getKey().equals("rate")) 
                    {
                    	rate = (double) pair.getValue();
                    }
                    if(pair.getKey().equals("sku")) 
                    {
                    	sku = (String) pair.getValue();
                    }
                    if(pair.getKey().equals("description")) 
                    {
                    	description = (String) pair.getValue();
                    }
                }
	            Element Line = document.createElement("Line");
	            root.appendChild(Line);
	            
	            Attr attr11 = document.createAttribute("lineItemNumber");
	            i = (i + 1);
	            attr11.setValue(i.toString());
	            Line.setAttributeNode(attr11);
	            
	            Attr attr12 = document.createAttribute("comment");
	            attr12.setValue("");
	            Line.setAttributeNode(attr12);
	            
	            Element productID = document.createElement("productID");
	            Line.appendChild(productID);
	            
	            Element itemIdentifier_Buyer = document.createElement("itemIdentifier");
	            productID.appendChild(itemIdentifier_Buyer);
	            
	            Attr attr13 = document.createAttribute("itemNumber");
	            attr13.setValue(sku);
	            itemIdentifier_Buyer.setAttributeNode(attr13);
	            
	            Attr attr14 = document.createAttribute("itemNumberQualifier");
	            attr14.setValue("BuyerAssigned");
	            itemIdentifier_Buyer.setAttributeNode(attr14);
	                        
	            Element itemIdentifier_Seller = document.createElement("itemIdentifier");
	            productID.appendChild(itemIdentifier_Seller);
	            
	            Attr attr15 = document.createAttribute("itemNumber");
	            attr15.setValue(sku);
	            itemIdentifier_Seller.setAttributeNode(attr15);
	            
	            Attr attr16 = document.createAttribute("itemNumberQualifier");
	            attr16.setValue("SellerAssigned");
	            itemIdentifier_Seller.setAttributeNode(attr16);
	            
	            Element requestedQuantity = document.createElement("requestedQuantity");
	            Line.appendChild(requestedQuantity);
	            
	            Attr attr17 = document.createAttribute("unitOfMeasure");
	            attr17.setValue("Each");
	            requestedQuantity.setAttributeNode(attr17);
	            
	            Attr attr18 = document.createAttribute("value");
	            attr18.setValue(Long.toString(quantity)); 
	            requestedQuantity.setAttributeNode(attr18);
	                        
	            Element unitPrice = document.createElement("unitPrice");
	            Line.appendChild(unitPrice);
	            
	            Element price = document.createElement("price");
	            price.appendChild(document.createTextNode(Double.toString(rate)));
	            unitPrice.appendChild(price);
            
            }

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource domSource = new DOMSource(document);
            StreamResult streamResult = new StreamResult(new File(xmlFilePath));
 
            transformer.transform(domSource, streamResult);
            System.out.println("Done creating XML File");
 
        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerException tfe) {
            tfe.printStackTrace();
        }
    }
}